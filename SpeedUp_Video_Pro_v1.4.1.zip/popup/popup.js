// SpeedUp Video Pro - Popup Controller Script (Manifest V3)
document.addEventListener('DOMContentLoaded', async () => {
  // ==========================================
  // 1. INIZIALIZZAZIONE ELEMENTI DOM & COSTANTI
  // ==========================================
  const TRIAL_DAYS = 7;
  const TRIAL_MS = TRIAL_DAYS * 24 * 60 * 60 * 1000;
  const LANDING_PAGE_URL = "https://x2-speedup.vercel.app";

  const paywall = document.getElementById('paywall');
  const speedControls = document.getElementById('speedControls');
  const trialBanner = document.getElementById('trialBanner');
  const trialBadgeText = document.getElementById('trialBadgeText');
  const upgradeTrialLink = document.getElementById('upgradeTrialLink');
  const ctaBuyBtn = document.getElementById('ctaBuyBtn');

  const keyInput = document.getElementById('keyInput');
  const activateBtn = document.getElementById('activateBtn');
  const statusMsg = document.getElementById('statusMsg');
  const logoutKeyBtn = document.getElementById('logoutKeyBtn');
  const footerLicenseStatus = document.getElementById('footerLicenseStatus');

  const slider = document.getElementById('speedSlider');
  const speedVal = document.getElementById('speedVal') || document.getElementById('speedValue');
  const presetButtons = document.querySelectorAll('.presets button, .preset-btn');
  const stepBtns = document.querySelectorAll('.step-btn');
  const customSpeedInput = document.getElementById('customSpeedInput');
  const resetBtn = document.getElementById('resetBtn');
  
  const statusBadge = document.getElementById('statusBadge');
  const statusText = document.getElementById('statusText');
  
  const togglePlayBtn = document.getElementById('togglePlayBtn');
  const playText = document.getElementById('playText');
  const toggleMuteBtn = document.getElementById('toggleMuteBtn');
  const muteText = document.getElementById('muteText');
  const seekBackBtn = document.getElementById('seekBackBtn');
  const seekFwdBtn = document.getElementById('seekFwdBtn');
  
  const pitchToggle = document.getElementById('pitchToggle');
  const loopToggle = document.getElementById('loopToggle');
  const hudToggle = document.getElementById('hudToggle');

  // CTA Links
  if (ctaBuyBtn) {
    ctaBuyBtn.addEventListener('click', () => {
      chrome.tabs.create({ url: LANDING_PAGE_URL });
    });
  }

  if (upgradeTrialLink) {
    upgradeTrialLink.addEventListener('click', (e) => {
      e.preventDefault();
      chrome.tabs.create({ url: LANDING_PAGE_URL });
    });
  }

  let currentSpeed = 1.0;
  let isPlaying = true;
  let isMuted = false;

  const storage = chrome.storage?.local || chrome.storage?.sync;

  // Calcola lo stato del periodo di prova di 7 giorni
  function calculateTrial(installDate) {
    if (!installDate) return { isTrialActive: true, daysLeft: 7, expired: false };
    const elapsed = Date.now() - installDate;
    const remaining = TRIAL_MS - elapsed;
    if (remaining <= 0) {
      return { isTrialActive: false, daysLeft: 0, expired: true };
    }
    const daysLeft = Math.max(1, Math.ceil(remaining / (24 * 60 * 60 * 1000)));
    return { isTrialActive: true, daysLeft: daysLeft, expired: false };
  }

  // ==========================================
  // 2. VERIFICA STATO LICENZA E TRIAL 7 GIORNI
  // ==========================================
  chrome.storage.local.get(['isLicensed', 'licenseKey', 'installDate'], async (data) => {
    let installDate = data.installDate;

    // Se l'installDate non esiste ancora, salvalo adesso
    if (!installDate) {
      installDate = Date.now();
      await chrome.storage.local.set({ installDate: installDate });
    }

    if (data.isLicensed && data.licenseKey) {
      const isValid = await verifyLicenseKey(data.licenseKey);
      if (isValid) {
        unlockFullAccess(true);
      } else {
        await chrome.storage.local.set({ isLicensed: false });
        evaluateTrialOrLock(installDate);
      }
    } else {
      evaluateTrialOrLock(installDate);
    }
  });

  function evaluateTrialOrLock(installDate) {
    const trialStatus = calculateTrial(installDate);

    if (trialStatus.isTrialActive) {
      // Trial attivo: mostra i controlli con banner informativo
      if (trialBanner) {
        trialBanner.style.display = 'flex';
        if (trialBadgeText) {
          trialBadgeText.textContent = `Trial: ${trialStatus.daysLeft} giorn${trialStatus.daysLeft === 1 ? 'o' : 'i'} rimanent${trialStatus.daysLeft === 1 ? 'i' : 'i'}`;
        }
      }
      if (footerLicenseStatus) {
        footerLicenseStatus.textContent = `Trial Attivo (${trialStatus.daysLeft}d)`;
      }
      checkCurrentTabAndShowControls();
    } else {
      // Trial scaduto: mostra schermata di blocco
      showPaywallLock();
    }
  }

  function unlockFullAccess(isPermanent = true) {
    if (trialBanner) trialBanner.style.display = 'none';
    if (footerLicenseStatus) {
      footerLicenseStatus.textContent = 'SpeedUp Video PRO • Licenza Attiva ✨';
    }
    checkCurrentTabAndShowControls();
  }

  // Carica impostazioni audio/HUD salvate
  storage.get(['defaultSpeed', 'hudEnabled', 'preservesPitch', 'loopVideo'], (data) => {
    if (data?.hudEnabled !== undefined && hudToggle) {
      hudToggle.checked = data.hudEnabled;
    }
    if (data?.preservesPitch !== undefined && pitchToggle) {
      pitchToggle.checked = data.preservesPitch;
    }
    if (data?.loopVideo !== undefined && loopToggle) {
      loopToggle.checked = data.loopVideo;
    }
  });

  async function checkCurrentTabAndShowControls() {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

    if (tab?.url && tab.url.includes("youtube.com")) {
      showYouTubeDisabledMessage();
    } else {
      showControls();
    }
  }

  function showYouTubeDisabledMessage() {
    if (paywall) paywall.style.display = 'none';
    if (speedControls) {
      speedControls.style.display = 'block';
      speedControls.innerHTML = `
        <div style="text-align: center; padding: 24px 14px; background: rgba(30, 41, 59, 0.65); backdrop-filter: blur(12px); border: 1px solid rgba(255, 255, 255, 0.08); border-radius: 16px;">
          <div style="display: inline-flex; align-items: center; justify-content: center; width: 42px; height: 42px; border-radius: 50%; background: rgba(225, 29, 72, 0.15); border: 1px solid rgba(225, 29, 72, 0.4); margin-bottom: 12px;">
            <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="#e11d48" stroke-width="2">
              <path d="M18.364 18.364A9 9 0 0 0 5.636 5.636m12.728 12.728A9 9 0 0 1 5.636 5.636m12.728 12.728L5.636 5.636"></path>
            </svg>
          </div>
          <h4 style="margin: 0 0 8px 0; font-size: 15px; font-weight: 700; color: #e11d48;">Disattivato su YouTube</h4>
          <p style="font-size: 12px; color: #64748b; margin: 0; line-height: 1.4;">
            L'estensione è totalmente sospesa su YouTube per non interferire con il player originale.
          </p>
        </div>
      `;
    }
  }

  function showControls() {
    if (paywall) paywall.style.display = 'none';
    if (speedControls) speedControls.style.display = 'block';
    initSpeedTabStatus();
  }

  function showPaywallLock() {
    if (paywall) paywall.style.display = 'flex';
    if (speedControls) speedControls.style.display = 'none';
    if (trialBanner) trialBanner.style.display = 'none';
    if (statusMsg) statusMsg.textContent = '';
  }

  // ==========================================
  // 3. GESTIONE RISCATTO CHIAVE LICENZA
  // ==========================================
  if (activateBtn) {
    activateBtn.addEventListener('click', async () => {
      const key = keyInput.value.trim();
      if (!key) {
        statusMsg.style.color = "#ef4444";
        statusMsg.textContent = "Inserisci una chiave di licenza valida.";
        return;
      }

      statusMsg.style.color = "#06b6d4";
      statusMsg.textContent = "Verifica in corso...";

      const isValid = await verifyLicenseKey(key);

      if (isValid) {
        await chrome.storage.local.set({ isLicensed: true, licenseKey: key });
        if (chrome.storage.sync) {
          chrome.storage.sync.set({ isLicensed: true, licenseKey: key });
        }
        statusMsg.style.color = "#10b981";
        statusMsg.textContent = "Licenza attivata con successo!";
        setTimeout(() => {
          unlockFullAccess(true);
        }, 500);
      } else {
        statusMsg.style.color = "#ef4444";
        statusMsg.textContent = "Chiave non valida o scaduta.";
      }
    });
  }

  if (logoutKeyBtn) {
    logoutKeyBtn.addEventListener('click', async () => {
      await chrome.storage.local.set({ isLicensed: false, licenseKey: '' });
      if (chrome.storage.sync) {
        chrome.storage.sync.set({ isLicensed: false, licenseKey: '' });
      }
      showPaywallLock();
    });
  }

  async function verifyLicenseKey(key) {
    try {
      const response = await fetch('https://tuo-dominio.vercel.app/api/verify-license', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ licenseKey: key })
      });

      const data = await response.json();
      return data.isValid === true;
    } catch (err) {
      console.error("Errore verifica licenza:", err);
      // Fallback test locali
      if (key.startsWith("PRO-")) {
        return true;
      }
      return false;
    }
  }

  // ==========================================
  // 4. CONTROLLO VELOCITÀ VIDEO
  // ==========================================
  async function initSpeedTabStatus() {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (tab?.url && tab.url.includes("youtube.com")) {
      return;
    }

    if (tab?.id) {
      try {
        chrome.tabs.sendMessage(tab.id, { action: 'GET_VIDEO_STATUS' }, (res) => {
          if (res && res.hasVideo) {
            updateStatusBadge(true, res.count);
            if (res.currentSpeed) setSpeedUI(res.currentSpeed);
            isPlaying = res.isPlaying ?? true;
            isMuted = res.isMuted ?? false;
            updatePlaybackUI();
          } else {
            updateStatusBadge(false, 0);
          }
        });
      } catch (e) {
        updateStatusBadge(false, 0);
      }
    }
  }

  // Funzione iniettata nella pagina attiva
  function changeVideoSpeed(targetSpeed) {
    if (window.location.hostname.includes("youtube.com")) return;

    const videos = document.querySelectorAll('video');
    videos.forEach(video => {
      video.playbackRate = targetSpeed;
    });
  }

  async function setSpeed(newSpeed) {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    
    if (tab?.url && tab.url.includes("youtube.com")) {
      return;
    }

    const speed = parseFloat(newSpeed).toFixed(2);
    currentSpeed = parseFloat(speed);
    
    setSpeedUI(currentSpeed);

    storage.set({ defaultSpeed: currentSpeed }).catch(() => {});

    if (tab?.id) {
      try {
        await chrome.scripting.executeScript({
          target: { tabId: tab.id, allFrames: true },
          func: changeVideoSpeed,
          args: [parseFloat(speed)]
        });
      } catch (err) {
        console.warn('Esecuzione script:', err);
      }

      chrome.tabs.sendMessage(tab.id, { action: 'SET_SPEED', speed: currentSpeed }).catch(() => {});
    }

    chrome.runtime.sendMessage({ action: 'UPDATE_BADGE', speed: currentSpeed }).catch(() => {});
  }

  function setSpeedUI(speedNum) {
    const speedStr = `${speedNum.toFixed(1)}x`;

    if (speedVal) speedVal.textContent = speedStr;
    if (slider) slider.value = speedNum.toFixed(2);
    if (customSpeedInput) customSpeedInput.value = speedNum.toFixed(2);

    presetButtons.forEach(btn => {
      const btnSpeed = parseFloat(btn.dataset.speed || btn.getAttribute('data-speed'));
      if (Math.abs(btnSpeed - speedNum) < 0.04) {
        btn.classList.add('active');
      } else {
        btn.classList.remove('active');
      }
    });
  }

  function updateStatusBadge(active, count = 0) {
    if (!statusText || !statusBadge) return;
    if (active) {
      statusText.textContent = `${count} Video ${count > 1 ? 'Trovati' : 'Trovato'}`;
      statusBadge.className = 'status-badge status-online';
    } else {
      statusText.textContent = 'Cerca video...';
      statusBadge.className = 'status-badge status-offline';
    }
  }

  function updatePlaybackUI() {
    if (playText) playText.textContent = isPlaying ? 'Pausa' : 'Riproduci';
    if (muteText) muteText.textContent = isMuted ? 'Audio OFF' : 'Audio ON';
  }

  // Listener eventi UI
  if (slider) {
    slider.addEventListener('input', (e) => setSpeed(e.target.value));
  }

  if (customSpeedInput) {
    customSpeedInput.addEventListener('change', (e) => setSpeed(e.target.value));
  }

  if (resetBtn) {
    resetBtn.addEventListener('click', () => setSpeed(1.0));
  }

  presetButtons.forEach(btn => {
    btn.addEventListener('click', () => {
      if (btn.dataset.speed) {
        setSpeed(btn.dataset.speed);
      }
    });
  });

  stepBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      const step = parseFloat(btn.dataset.step);
      if (!isNaN(step)) {
        setSpeed(currentSpeed + step);
      }
    });
  });

  if (togglePlayBtn) {
    togglePlayBtn.addEventListener('click', async () => {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (tab?.url && tab.url.includes("youtube.com")) return;

      if (tab?.id) {
        chrome.tabs.sendMessage(tab.id, { action: 'TOGGLE_PLAY' }, (res) => {
          if (res && res.isPlaying !== undefined) {
            isPlaying = res.isPlaying;
            updatePlaybackUI();
          }
        });
      }
    });
  }

  if (toggleMuteBtn) {
    toggleMuteBtn.addEventListener('click', async () => {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (tab?.url && tab.url.includes("youtube.com")) return;

      if (tab?.id) {
        chrome.tabs.sendMessage(tab.id, { action: 'TOGGLE_MUTE' }, (res) => {
          if (res && res.isMuted !== undefined) {
            isMuted = res.isMuted;
            updatePlaybackUI();
          }
        });
      }
    });
  }

  if (seekBackBtn) {
    seekBackBtn.addEventListener('click', async () => {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (tab?.url && tab.url.includes("youtube.com")) return;

      if (tab?.id) {
        chrome.tabs.sendMessage(tab.id, { action: 'SEEK', seconds: -10 }).catch(() => {});
      }
    });
  }

  if (seekFwdBtn) {
    seekFwdBtn.addEventListener('click', async () => {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (tab?.url && tab.url.includes("youtube.com")) return;

      if (tab?.id) {
        chrome.tabs.sendMessage(tab.id, { action: 'SEEK', seconds: 10 }).catch(() => {});
      }
    });
  }

  if (pitchToggle) {
    pitchToggle.addEventListener('change', async (e) => {
      const val = e.target.checked;
      await storage.set({ preservesPitch: val });
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (tab?.url && tab.url.includes("youtube.com")) return;

      if (tab?.id) {
        chrome.tabs.sendMessage(tab.id, { action: 'SET_PITCH', preservesPitch: val }).catch(() => {});
      }
    });
  }

  if (loopToggle) {
    loopToggle.addEventListener('change', async (e) => {
      const val = e.target.checked;
      await storage.set({ loopVideo: val });
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (tab?.url && tab.url.includes("youtube.com")) return;

      if (tab?.id) {
        chrome.tabs.sendMessage(tab.id, { action: 'SET_LOOP', loop: val }).catch(() => {});
      }
    });
  }

  if (hudToggle) {
    hudToggle.addEventListener('change', async (e) => {
      const val = e.target.checked;
      await storage.set({ hudEnabled: val });
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (tab?.url && tab.url.includes("youtube.com")) return;

      if (tab?.id) {
        chrome.tabs.sendMessage(tab.id, { action: 'SET_HUD', enabled: val }).catch(() => {});
      }
    });
  }
});
